// netlify/functions/yt-transcript.mjs
var config = {
  path: "/api/yt-transcript"
};
var UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Safari/537.36";
var yt_transcript_default = async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { status: 204, headers: cors() });
  if (req.method !== "POST") return json({ error: "method_not_allowed" }, 405);
  let body;
  try {
    body = await req.json();
  } catch {
    return json({ error: "invalid_json" }, 400);
  }
  const videoId = (body?.videoId || "").toString().trim().replace(/^.*v=/, "").slice(0, 20);
  if (!/^[\w-]{6,}$/.test(videoId)) return json({ error: "bad_video_id" }, 400);
  try {
    const tracks = await getCaptionTracks(videoId);
    if (!tracks.length) {
      return json({ ok: false, videoId, error: "no_captions", message: "Este video no tiene subt\xEDtulos p\xFAblicos disponibles." });
    }
    const track = tracks.find((t) => /^es/i.test(t.languageCode)) || tracks[0];
    const { text, segments } = await fetchTranscript(track.baseUrl);
    if (!text) return json({ ok: false, videoId, error: "empty_transcript", message: "No pude leer el texto de los subt\xEDtulos." });
    return json({ ok: true, videoId, lang: track.languageCode || "", text, segments, at: (/* @__PURE__ */ new Date()).toISOString() });
  } catch (e) {
    return json({ ok: false, videoId, error: "transcript_error", message: e?.message || String(e) }, 502);
  }
};
async function getCaptionTracks(videoId) {
  const res = await fetch(`https://www.youtube.com/watch?v=${videoId}&hl=es`, {
    headers: { "User-Agent": UA, "Accept-Language": "es-ES,es;q=0.9,en;q=0.8", "Cookie": "CONSENT=YES+1" }
  });
  const html = await res.text();
  const m = html.match(/"captions":\s*(\{.*?\}),"videoDetails"/s) || html.match(/ytInitialPlayerResponse\s*=\s*(\{.+?\});/s);
  if (!m) return [];
  let tracks = [];
  try {
    if (m[0].startsWith('"captions"')) {
      const caps = JSON.parse(m[1]);
      tracks = caps?.playerCaptionsTracklistRenderer?.captionTracks || [];
    } else {
      const pr = JSON.parse(m[1]);
      tracks = pr?.captions?.playerCaptionsTracklistRenderer?.captionTracks || [];
    }
  } catch {
    tracks = [];
  }
  return tracks.map((t) => ({ baseUrl: t.baseUrl, languageCode: t.languageCode, name: t.name?.simpleText || "" })).filter((t) => t.baseUrl);
}
async function fetchTranscript(baseUrl) {
  const url = baseUrl + (baseUrl.includes("fmt=") ? "" : "&fmt=json3");
  const res = await fetch(url, { headers: { "User-Agent": UA } });
  const raw = await res.text();
  try {
    const j = JSON.parse(raw);
    if (Array.isArray(j.events)) {
      const segments = [];
      for (const ev of j.events) {
        if (!ev.segs) continue;
        const t = ev.segs.map((s) => s.utf8 || "").join("").replace(/\n/g, " ").trim();
        if (t) segments.push({ start: Math.round((ev.tStartMs || 0) / 1e3), text: t });
      }
      return { text: segments.map((s) => s.text).join(" ").replace(/\s+/g, " ").trim(), segments };
    }
  } catch {
  }
  const segs = [];
  const re = /<text[^>]*start="([\d.]+)"[^>]*>([\s\S]*?)<\/text>/g;
  let mm;
  while ((mm = re.exec(raw)) !== null) {
    const t = decode(mm[2]).replace(/\s+/g, " ").trim();
    if (t) segs.push({ start: Math.round(parseFloat(mm[1]) || 0), text: t });
  }
  return { text: segs.map((s) => s.text).join(" ").replace(/\s+/g, " ").trim(), segments: segs };
}
function decode(s) {
  return String(s || "").replace(/<[^>]+>/g, " ").replace(/&amp;/g, "&").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/&#(\d+);/g, (_, n) => String.fromCodePoint(+n));
}
function cors() {
  return { "Access-Control-Allow-Origin": "*", "Access-Control-Allow-Methods": "POST, OPTIONS", "Access-Control-Allow-Headers": "Content-Type" };
}
function json(payload, status = 200) {
  return new Response(JSON.stringify(payload), { status, headers: { "Content-Type": "application/json", ...cors() } });
}
export {
  config,
  yt_transcript_default as default
};
