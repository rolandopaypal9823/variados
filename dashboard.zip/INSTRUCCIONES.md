# 🚀 Cómo instalar tu Dashboard (10 minutos, sin saber programar)

Es como instalar un programa: bajás el archivo, lo subís y listo. No necesitás GitHub ni saber código.

---

## Paso 1 — Subir el dashboard a Netlify (gratis)

1. Entrá a **https://app.netlify.com/drop**
2. Si no tenés cuenta, creá una **gratis** (con tu Google o email). 
3. **Arrastrá la carpeta** de este dashboard (la que descomprimiste del ZIP) a la zona que dice *"Drag and drop your site folder here"*.
4. Esperá ~1 minuto. ✅ Tu dashboard queda online en una dirección tipo `algo-random.netlify.app`.
5. (Opcional) Tocá **"Site configuration → Change site name"** para ponerle un nombre lindo.

✅ **Ya funciona.** Podés subir tu data y ver embudo, rankings, tendencias, reporte, calendario y el Radar de noticias. Nada de esto necesita configuración extra.

---

## Paso 2 (opcional) — Activar la IA 🧠

La IA usa **Anthropic (Claude)**. Es tu cuenta y tu gasto (pagás solo lo que uses).

1. Sacá tu key en **console.anthropic.com** → cargá un poco de saldo → **API Keys → Create Key** (copiá la que empieza con `sk-ant-`).
2. En Netlify: tu sitio → **Site configuration → Environment variables → Add a variable**.
   - Key: `ANTHROPIC_API_KEY` — Value: tu key — **Save**.
3. Andá a **Deploys** y volvé a **arrastrar la carpeta** (o "Trigger deploy") para que tome la key.

✅ Chat e insights activos.

---

## Paso 3 (opcional) — Activar Competidores 🕵️ (gratis)

Usa la **YouTube Data API** (gratis, no accede a ninguna cuenta).

1. En **console.cloud.google.com**: **New Project** → **APIs & Services → Library** → buscá **"YouTube Data API v3"** → **Enable**.
2. **Credentials → Create credentials → API key** (copiá la que empieza con `AIza...`).
3. En Netlify: **Environment variables → Add a variable** → Key: `YOUTUBE_API_KEY` → Value: tu key → **Save**.
4. Volvé a arrastrar la carpeta (o "Trigger deploy").

✅ Competidores activo.

---

## ¿Cómo sé qué está activo?

Abrí `https://TU-SITIO.netlify.app/api/whoami` en el navegador. Te dice si tus keys están cargadas (sin revelarlas).

## ¿Cómo actualizo a una versión nueva?

Te paso un ZIP nuevo, lo descomprimís y lo **volvés a arrastrar**. Tu data guardada en la nube se mantiene.

## Preguntas frecuentes

- **¿Pago Netlify?** No para empezar, el plan gratis alcanza.
- **¿Sirve sin keys?** Sí, toda la analítica + el Radar funcionan sin ninguna key.
- **¿Mi data la ve alguien?** No: es tu sitio, tu almacenamiento, tus keys.
